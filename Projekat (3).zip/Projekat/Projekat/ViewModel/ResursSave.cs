﻿using Projekat.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Xml.Serialization;

namespace Projekat.ViewModel
{
    [Serializable]
    public class ResursSave
    {
      
        private string _name;
        private string _id;
        private string _desc;
        private string _type;
        private bool _renewable;
        private bool _strategicValue;
        private bool _exploitable;
        private string _munit;
        private double _price;
        private DateTime _discoveryDate;
        private string _freq;
        private byte[] _image;
        private List<string> _tags;


        public ResursSave(List<Etiketa> et, string id, string name, string opis,
            string unit, string freq, string type, bool renew, bool svalue, bool exploit, double price, DateTime Date, ImageSource image)
        {
            Name = name;
            Id = id;
            Munit = unit;
            Type = type;
            Desc = opis;
            Renewable = renew;
            StrategicValue = svalue;
            Exploitable = exploit;
            Price = price;
            _discoveryDate = Date;
            Freq = freq;
            Tags = new List<String>();
            foreach (Etiketa e in et)
            {
                Tags.Add(e.Id);
            }
            Img = getJPGFromImageControl(image as BitmapImage);
        }
        public byte[] getJPGFromImageControl(BitmapImage imageC)
        {
            MemoryStream memStream = new MemoryStream();
            JpegBitmapEncoder encoder = new JpegBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(imageC));
            encoder.Save(memStream);
            return memStream.ToArray();
        }
        public ResursSave() { }
        public byte[] Img
        {
            get
            {
                return _image;
            }
            set
            {
                if (_image != value)
                {
                    _image = value;
                }
            }
        }
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (value != _name)
                {
                    _name = value;
                }
            }
        }
        public string Freq
        {
            get
            {
                return _freq;
            }
            set
            {
                if (value != _freq)
                {
                    _freq = value;
                }
            }
        }
        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                if (value != _id)
                {
                    _id = value;
                }
            }
        }
        public string Desc
        {
            get
            {
                return _desc;
            }
            set
            {
                if (value != _desc)
                {
                    _desc = value;
                }
            }
        }
        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                if (value != _type)
                {
                    _type = value;
                }
            }
        }
        public bool Renewable
        {
            get
            {
                return _renewable;
            }
            set
            {
                if (value != _renewable)
                {
                    _renewable = value;
                }
            }
        }
        public bool StrategicValue
        {
            get
            {
                return _strategicValue;
            }
            set
            {
                if (value != _strategicValue)
                {
                    _strategicValue = value;
                }
            }
        }
        public bool Exploitable
        {
            get
            {
                return _exploitable;
            }
            set
            {
                if (value != _exploitable)
                {
                    _exploitable = value;
                }
            }
        }
        public string Munit
        {
            get
            {
                return _munit;
            }
            set
            {
                if (value != _munit)
                {
                    _munit = value;
                }
            }
        }
        public double Price
        {
            get
            {
                return _price;
            }
            set
            {
                if (value != _price)
                {
                    _price = value;
                }
            }
        }
        public DateTime DiscoveryDate
        {
            get
            {
                return _discoveryDate;
            }
            set
            {
                if (value != _discoveryDate)
                {
                    _discoveryDate = value;
                }
            }
        }

        public List<string> Tags
        {
            get
            {
                return _tags;
            }
            set
            {
                if (value != _tags)
                {
                    _tags = value;
                }

            }
        }
    }
}
