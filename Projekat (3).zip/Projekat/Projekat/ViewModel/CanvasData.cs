﻿using Projekat.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Projekat.ViewModel
{
    [Serializable]
    public class CanvasData
    {
        public Resurs Item { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public CanvasData(Resurs r, double x,double y)
        {
            Item = r;
            X = x;
            Y = y;
        }

    }
}
