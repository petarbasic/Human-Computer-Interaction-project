﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat.ViewModel
{
    [Serializable]
    public class EtiketaSave
    {
        private string _id;
        private string _boja;
        private string _opis;
      
        public EtiketaSave(string i, string o, string c)
        {
            Id = i;
            Desc = o;
            Boja = c;

        }
        public EtiketaSave() { }
        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                if (value != _id)
                {
                    _id = value;
                }

            }
        }
        public string Desc
        {
            get
            {
                return _opis;
            }
            set
            {
                if (value != _opis)
                {
                    _opis = value;
                }

            }
        }
        public string Boja
        {
            get
            {
                return _boja;
            }
            set
            {
                if (value != _boja)
                {
                    _boja = value;
                }

            }
        }
    }
}
