﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat.ViewModel
{
    [Serializable]
    public class CanvasDataSave
    {
        public string id { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public CanvasDataSave(string r, double x, double y)
        {
            id = r;
            X = x;
            Y = y;
        }
    }
}
