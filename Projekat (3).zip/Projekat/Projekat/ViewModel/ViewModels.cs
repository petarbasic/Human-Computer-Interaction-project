﻿using Projekat.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Xml.Serialization;

namespace Projekat.ViewModel
{
    public class ViewModels
    {
        private List<ResursSave> rs;
        private List<EtiketaSave> es;
        private List<TypeSave> ts;
        private List<CanvasDataSave> cds;
        public ViewModels()
        {

            rs = new List<ResursSave>();
            es = new List<EtiketaSave>();
            ts = new List<TypeSave>();
            cds = new List<CanvasDataSave>();
            foreach (Resurs r in MainWindow.Resursi)
            {
                rs.Add(new ResursSave(r.Tags, r.Id, r.Name, r.Desc, r.Munit, r.Freq, r.Type.Id, r.Renewable, r.StrategicValue, r.Exploitable, r.Price, r.DiscoveryDate, r.Img.Source));
            }
            foreach(Etiketa e in MainWindow.Etikete)
            {
                es.Add(new EtiketaSave(e.Id, e.Desc, e.Boja.ToString()));
            }
            foreach(Tip t in MainWindow.Tipovi)
            {
                ts.Add(new TypeSave(t.Id,t.Name,t.Desc,t.Img.Source,t.Resource));
            }
            foreach(CanvasData cd in MainWindow.Resursi_Canvas)
            {
                cds.Add(new CanvasDataSave(cd.Item.Id, cd.X, cd.Y));
            }

        }
        public void Save()
        {
            
            try
            {
                FileStream stream = File.Create("resursi");
                FileStream streamT = File.Create("tipovi");
                FileStream streamE = File.Create("etikete");
                FileStream streamCD = File.Create("CanvasData");
                var formatter = new BinaryFormatter();
               formatter.Serialize(streamT, ts);
                formatter.Serialize(streamE, es);
                formatter.Serialize(stream, rs);
                formatter.Serialize(streamCD, cds);
                stream.Close();
                streamE.Close();
                streamT.Close();
                streamCD.Close();
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Failed to serialize. Reason: " + e.Message);
                throw;
            }
            
            
            
        }
        public void Load()
        {
            FileStream stream = null;
            FileStream streamT = null;
            FileStream streamE = null;
            FileStream streamCD = null;
            if (File.Exists("tipovi") && File.Exists("resursi") && File.Exists("etikete"))
            {
                stream = File.OpenRead("resursi");
                streamT = File.OpenRead("tipovi");
                streamE = File.OpenRead("etikete");
                if (File.Exists("CanvasData"))
                {
                    streamCD = File.OpenRead("CanvasData");
                }
            }
            else
            {
                return;
            }
            
            try
            {
                
                var formatter = new BinaryFormatter();
                es= (List<EtiketaSave>)formatter.Deserialize(streamE);
                ts = (List<TypeSave>)formatter.Deserialize(streamT);
                rs = (List<ResursSave>)formatter.Deserialize(stream);
               
                    cds = (List<CanvasDataSave>)formatter.Deserialize(streamCD);
                   streamCD.Close(); 
                
               
                
                stream.Close();
                streamE.Close();
                streamT.Close();
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Failed to deserialize. Reason: " + e.Message);
                return;
            }

            loadTags();
            loadTypes();

            foreach (ResursSave r in rs)
            {
                List<Etiketa> l = new List<Etiketa>();
                Tip ti = null;

                foreach (Etiketa e in MainWindow.Etikete)
                {
                    if (r.Tags.Contains(e.Id))
                    {
                        l.Add(e);
                    }
                }
                foreach(Tip t in MainWindow.Tipovi)
                {
                    if (t.Id.Equals(r.Type))
                    {
                        ti = t;
                    }
                }
                System.Windows.Controls.Image ima = new System.Windows.Controls.Image();
                ima.Source = ByteToImage(r.Img);
                MainWindow.Resursi.Add(new Resurs(l,r.Id,r.Name,r.Desc,r.Munit,r.Freq,ti,r.Renewable,r.StrategicValue,r.Exploitable,r.Price,r.DiscoveryDate,ima));
            }
            loadResourcesIntoTypes();
            loadCanvasData();
        }
        private void loadResourcesIntoTypes()
        {
            foreach(Tip t in MainWindow.Tipovi)
            {
                foreach(Resurs r in MainWindow.Resursi)
                {
                    if (r.Type.Id.Equals(t.Id))
                    {
                        t.Resource.Add(r);
                      

                    }
                }
            }
        }
        private void loadCanvasData( )
        {
            foreach (Resurs r in MainWindow.Resursi)
            {
                foreach(CanvasDataSave c in cds)
                {
                    if (r.Id.Equals(c.id))
                    {
                        MainWindow.Resursi_Canvas.Add(new CanvasData(r, c.X, c.Y));
                    }
                }
               
            }
           
        }
        private void loadTypes()
        {
            System.Windows.Controls.Image ima = new System.Windows.Controls.Image();
            foreach (TypeSave t in ts)
            {
                ima.Source = ByteToImage(t.Img);
                MainWindow.Tipovi.Add(new Tip(t.Id,t.Name,t.Desc,ima));
            }
        }
        private void loadTags()
        {
            foreach(EtiketaSave e in es)
            {
                MainWindow.Etikete.Add(new Etiketa(e.Id,e.Desc, ConvertStringToColor(e.Boja)));
            }
        }
        public static ImageSource ByteToImage(byte[] imageData)
        {
            BitmapImage biImg = new BitmapImage();
            MemoryStream ms = new MemoryStream(imageData);
            biImg.BeginInit();
            biImg.StreamSource = ms;
            biImg.EndInit();

            ImageSource imgSrc = biImg as ImageSource;

            return imgSrc;
        }
        public System.Windows.Media.Color ConvertStringToColor(String hex)
        {
            //remove the # at the front
            hex = hex.Replace("#", "");

            byte a = 255;
            byte r = 255;
            byte g = 255;
            byte b = 255;

            int start = 0;

            //handle ARGB strings (8 characters long)
            if (hex.Length == 8)
            {
                a = byte.Parse(hex.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
                start = 2;
            }

            //convert RGB characters to bytes
            r = byte.Parse(hex.Substring(start, 2), System.Globalization.NumberStyles.HexNumber);
            g = byte.Parse(hex.Substring(start + 2, 2), System.Globalization.NumberStyles.HexNumber);
            b = byte.Parse(hex.Substring(start + 4, 2), System.Globalization.NumberStyles.HexNumber);

            return System.Windows.Media.Color.FromArgb(a, r, g, b);
        }

        
    }
}
