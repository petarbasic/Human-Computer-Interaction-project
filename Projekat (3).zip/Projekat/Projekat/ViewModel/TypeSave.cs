﻿using Projekat.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Projekat.ViewModel
{
    [Serializable]
    public class TypeSave
    {
        private string _id;
        private string _name;
        private string _desc;
        private byte[] _image;

        private List<string> _resource;

        public TypeSave() { }
        public TypeSave(string id, string s, string d, ImageSource image,ObservableCollection<Resurs> lista)
        {
           
            Id = id;
            Name = s;
            Desc = d;
            Img = getJPGFromImageControl(image as BitmapImage);
            Resource = new List<string>();
            foreach(Resurs r in lista)
            {
                Resource.Add(r.Id);
            }
        }
        public byte[] getJPGFromImageControl(BitmapImage imageC)
        {
            MemoryStream memStream = new MemoryStream();
            JpegBitmapEncoder encoder = new JpegBitmapEncoder();
            System.Console.WriteLine(imageC == null);
            encoder.Frames.Add(BitmapFrame.Create(imageC));
            encoder.Save(memStream);
            return memStream.ToArray();
        }
        public List<string> Resource
        {
            get
            {
                return _resource;
            }
            set
            {
                if (_resource != value)
                {
                    _resource = value;
                }
            }
        }
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (value != _name)
                {
                    _name = value;
                }
            }
        }
        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                if (value != _id)
                {
                    _id = value;
                }
            }
        }

        public string Desc
        {
            get
            {
                return _desc;
            }
            set
            {
                if (value != _desc)
                {
                    _desc = value;
                }
            }
        }


        public byte[] Img
        {
            get
            {
                return _image;
            }
            set
            {
                if (_image != value)
                {
                    _image = value;
                }
            }
        }
    }
}
