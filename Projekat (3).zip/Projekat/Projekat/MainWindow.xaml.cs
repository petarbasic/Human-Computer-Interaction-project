﻿using Projekat.Dialogs;
using Projekat.Model;
using Projekat.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataObject = System.Windows.DataObject;
using DragDropEffects = System.Windows.DragDropEffects;
using DragEventArgs = System.Windows.DragEventArgs;
using Label = System.Windows.Controls.Label;
using MouseEventArgs = System.Windows.Input.MouseEventArgs;
using TreeView = System.Windows.Controls.TreeView;

namespace Projekat
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    
    {
        public static ObservableCollection<Tip> Tipovi
        {
            get;
            set;
        }
        public static ObservableCollection<Resurs> Resursi
        {
            get;
            set;
        }
        public static ObservableCollection<Etiketa> Etikete
        {
            get;
            set;
        }
        public static List<CanvasData> Resursi_Canvas
        {
            get;
            set;
        }
        Point startPoint = new Point();
        TreeViewItem treeViewItem = new TreeViewItem();
        Resurs res = null;
        StackPanel sp = null;
        StackPanel _selectedPanel = null;
        public StackPanel selectedPanel
        {
            get
            {
                return _selectedPanel;
            }
            set
            {
                if (_selectedPanel != value)
                {
                    _selectedPanel = value;
                    OnPropertyChanged("selectedPanel");
                }
            }
        }
        public static readonly List<string> units = new List<string>();
        public static readonly List<string> freq = new List<string>();
        #region PropertyChangedNotifier
        protected virtual void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        public MainWindow()
        {
            InitializeComponent();
            Tipovi = new ObservableCollection<Tip>();
            Resursi = new ObservableCollection<Resurs>();
            Etikete = new ObservableCollection<Etiketa>();
            Resursi_Canvas = new List<CanvasData>();
            Image i = new Image();
            this.DataContext = this;
            ViewModels vm = new ViewModels();
            vm.Load();
            loadCanvas();
            MessageBoxManager.Yes = "Da";
            MessageBoxManager.No = "Ne";
            MessageBoxManager.Register();
            units.Add("Merica"); units.Add("Barel"); units.Add("Tona"); units.Add("Kilogram");
            freq.Add("Redak"); freq.Add("Cest"); freq.Add("Univerzalan");
            RoutedCommand cmd = new RoutedCommand();
            cmd.InputGestures.Add(new KeyGesture(Key.D,ModifierKeys.Control));
            CommandBindings.Add(new CommandBinding(cmd, MenuItem_Click_Demo));
        }
        
    

    private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            var s = new ShowAllWindow();
            s.ShowDialog();

        }
        private void AddResource_Click(object sender, RoutedEventArgs e)
        {
            var s =new  ResourceAddWindow();
            s.ShowDialog();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            var s = new AddWindow();
            s.ShowDialog();
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            if (Tipovi.Count != 0)
            {
                var s = new ChangeType(-1);
                s.Show();
            }
            else
            {
                System.Windows.MessageBox.Show("Ne postoje resursi za izmenu!");
            }
        }

        private void ChangeResource_Click_3(object sender, RoutedEventArgs e)
        {
            if (Resursi.Count != 0)
            {
                var s = new ChangeResource(-1);
                s.ShowDialog();
            }
            else
            {
                System.Windows.MessageBox.Show("Ne postoje resursi za izmenu!");
            }
            
        }
        private void AddTagClick(object sender, RoutedEventArgs e)
        {
            var s = new AddTagWindow();
            s.ShowDialog();
        }
        private void ChangeTagClick(object sender, RoutedEventArgs e)
        {
            var s = new ChangeTagWindow(-1);
            s.ShowDialog();
        }

        private void ShowAllResource_Click_3(object sender, RoutedEventArgs e)
        {
            var s = new ShowResourceWindow();
            s.Show();
        }

        private void ShowTags_Click_3(object sender, RoutedEventArgs e)
        {
            var s = new ShowTagWindow();
            s.Show();
        }
        private void ListView_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            startPoint = e.GetPosition(null);
        }
        private void StackPanel_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            startPoint = e.GetPosition(null);
            if (selectedPanel != null)
            {
                selectedPanel.Background.Opacity=0;
            }
            selectedPanel = sender as StackPanel;
            selectedPanel.Background= new SolidColorBrush(Color.FromArgb(0xFF, 0xFF, 0, 0));
        }
       /* IkonicaNaMapi cm = e.Data.GetData(typeof(Image)) as IkonicaNaMapi;
                if (CanDrop(e.GetPosition(this.mapaCanvas).X - 20, e.GetPosition(this.mapaCanvas).Y - 20, cm))
        public bool CanDrop(double x, double y, IkonicaNaMapi klasa)
        {
            for (int i = 0; i < SpomeniciNaMapi.Count; i++)
            {
                IkonicaNaMapi canvasModel = SpomeniciNaMapi[i];
                if (canvasModel != klasa)
                {
                    if (Math.Abs(canvasModel.X - x) < 25 && Math.Abs(canvasModel.Y - y) < 30)
                    {
                        System.Windows.MessageBox.Show("Spomenici se ne smeju preklapati", "", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return false;
                    }
                }
            }
            return true;
        }*/
        private void SP_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = e.GetPosition(null);
            Vector diff = startPoint - mousePos;

            if (e.LeftButton == MouseButtonState.Pressed &&
                (Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance))
            {
                sp = sender as StackPanel;
                UIElement[] a = new UIElement[2];
                sp.Children.CopyTo(a, 0);
               foreach (CanvasData r in Resursi_Canvas)
                {
                    if (((string)((Label)a[1]).Content).Equals(r.Item.Id))
                    {
                        res = r.Item;
                        break;
                    }
                }
              
                    DataObject dragData = new DataObject("myFormat", res);
                    DragDrop.DoDragDrop(sp, dragData, DragDropEffects.Move);
                    
               
            }
        }
        private void ListView_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = e.GetPosition(null);
            Vector diff = startPoint - mousePos;

            if (e.LeftButton == MouseButtonState.Pressed &&
                (Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance))
            {

                TreeView treeView = sender as TreeView;
                treeViewItem =
                    FindAncestor<TreeViewItem>((DependencyObject)e.OriginalSource);
                if (treeViewItem != null)
                {
                    if (treeView.SelectedItem is Resurs)
                    {
                        res = (Resurs)treeView.SelectedItem;                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
                if (treeViewItem != null && res!= null)
                {
                    // Initialize the drag & drop operation
                    DataObject dragData = new DataObject("myFormat", res);
                    DragDrop.DoDragDrop(treeViewItem, dragData, DragDropEffects.Move);
                    sp = null;
                }
               
            }
        }

        private static T FindAncestor<T>(DependencyObject current) where T : DependencyObject
        {
            do
            {
                if (current is T)
                {
                    return (T)current;
                }
                current = VisualTreeHelper.GetParent(current);
            }
            while (current != null);
            return null;
        }

        private void Canvas_DragEnter(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent("myFormat") || sender == e.OriginalSource)
            {
                e.Effects = System.Windows.DragDropEffects.None;
            }
        }

        private void Canvas_Drop(object sender, DragEventArgs e)
        {
            Resurs r = e.Data.GetData("myFormat") as Resurs;
            if (sp != null)
            {
                canvas.Children.Remove(sp);
                int i = 0;
                foreach (CanvasData cd in Resursi_Canvas)
                {
                    if (cd.Item.Id.Equals(res.Id))
                    {
                        Resursi_Canvas.RemoveAt(i);
                        break;
                    }
                    i++;
                }
            }
            else
            {
                if (r != null)
                {
                    foreach (UIElement u in canvas.Children)
                    {
                        StackPanel stackpane = u as StackPanel;
                        if (stackpane != null)
                        {
                            UIElement[] a = new UIElement[2];
                            stackpane.Children.CopyTo(a, 0);
                            if (r.Id.Equals(((Label)a[1]).Content))
                            {
                                return;
                            }
                        }
                       
                    }
                }
               
            }
           
            if (r != null) {
                
                Point mousePos = e.GetPosition((Canvas)sender);
                StackPanel spa = new StackPanel();
                Image i = new Image();
                i.Source = r.Img.Source;
                i.Width = 17;
                i.Height = 17;
                spa.Children.Add(i);
                Label l = new Label();
                l.Content = (r.Id);
                l.FontSize = 8;
                spa.Children.Add(l);
                spa.PreviewMouseLeftButtonDown += StackPanel_PreviewMouseLeftButtonDown;
                spa.MouseMove += SP_MouseMove;
                spa.AllowDrop = false;
                spa.Width = 21;
                spa.Height = 30;
                spa.ToolTip = toolTipPane(r);
                mousePos = checkXY(mousePos,spa);
                Resursi_Canvas.Add(new CanvasData(r, mousePos.X, mousePos.Y));
               
                canvas.Children.Add(spa);
                
                Canvas.SetLeft(spa, mousePos.X);
                Canvas.SetTop(spa, mousePos.Y);

                sp = null;
                canvas.ReleaseMouseCapture();
                selectedPanel = null;
            }
        }
        private StackPanel toolTipPane(Resurs r)
        {
            StackPanel toolPane = new StackPanel();
            StackPanel labels = new StackPanel();
            Label id = new Label();
            Label name = new Label();
            Label tip = new Label();
            Label cena = new Label();
            id.Content=    "Id:       "+r.Id;
            tip.Content = "Tip:      " + r.Type.Name;
            name.Content = "Naziv: "+r.Name;
            cena.Content = "Cena:   " + r.Price.ToString();
            Image i = new Image();
            i.Source = r.Img.Source;
            i.Width = 40;
            i.Height = 40;
            toolPane.Children.Add(i);
            labels.Children.Add(id);
            labels.Children.Add(name);
            labels.Children.Add(tip);
            labels.Children.Add(cena);
            toolPane.Children.Add(labels);
            return toolPane;
        }
        private Point checkXY(Point p,StackPanel s)
        {
            Point retval = p;
            foreach(CanvasData cd in Resursi_Canvas)
            {
                double w = Math.Abs(cd.X - p.X);
                double h = Math.Abs(cd.Y - p.Y);
                if (w<30 && h< 28)
                {
                    retval = new Point((cd.X-20),(cd.Y));
                }
            }
            return retval;
        }
        protected override void OnClosed(EventArgs e)
        {

            var vm = new ViewModels();
            vm.Save();
            base.OnClosed(e);
            System.Windows.Application.Current.Shutdown();
        }
        public void loadCanvas()
        {
            foreach (CanvasData cd in Resursi_Canvas)
            {
                StackPanel sp = new StackPanel();
                Image i = new Image();
                i.Source = cd.Item.Img.Source;
                i.Width = 17;
                i.Height = 17;
                sp.Children.Add(i);
                Label l = new Label();
                l.Content = (cd.Item.Id);
                l.FontSize = 8;
                sp.Children.Add(l);
                sp.PreviewMouseLeftButtonDown += StackPanel_PreviewMouseLeftButtonDown;
                sp.MouseMove += SP_MouseMove;
                sp.AllowDrop = false;
                sp.Width = 21;
                sp.Height = 30;
                sp.ToolTip = toolTipPane(cd.Item);
                canvas.Children.Add(sp);

                Canvas.SetLeft(sp, cd.X);
                Canvas.SetTop(sp, cd.Y);
            }
        }

        private void Delete_Button_Click(object sender, RoutedEventArgs e)
        {
            if (selectedPanel != null)
            {
                Point relativePoint = selectedPanel.TransformToAncestor(canvas)
                              .Transform(new Point(0, 0));
                UIElement[] a = new UIElement[2];
                selectedPanel.Children.CopyTo(a, 0);
                canvas.Children.Remove(selectedPanel);
                foreach(CanvasData cd in Resursi_Canvas)
                {
                    if (cd.Item.Id.Equals((string)((Label)a[1]).Content) && relativePoint.X.Equals(cd.X) && relativePoint.Y.Equals(cd.Y))
                    {
                        Resursi_Canvas.Remove(cd);
                        break;
                    }
                }
            }selectedPanel = null;
        }

        private void MenuItem_Click_Help(object sender, RoutedEventArgs e)
        {
            Process proc = new Process();
            proc.StartInfo = new ProcessStartInfo(@"C:\Users\Petar\Downloads\fb.pdf");
            proc.Start();
        }
        
        private void MenuItem_Click_Demo(object sender, RoutedEventArgs e)
        {
            ResourceAddWindow raw = new ResourceAddWindow();
            raw.Show();
                    raw.demo_mode();
            
        }
       
    }
}
