﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Controls;
using System.ComponentModel;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using System.Windows.Input;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows;
using System.Collections.ObjectModel;

namespace Projekat.Model
{
    public class Tip : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }
        private string _id;
        private string _name;
        private string _desc;
        private System.Windows.Controls.Image _image;
        private ObservableCollection<Resurs> _resursi;


        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (value != _name)
                {
                    _name = value;
                    OnPropertyChanged("Name");
                }
            }
        }
        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                if (value != _id)
                {
                    _id = value;
                    OnPropertyChanged("Id");
                }
            }
        }

        public string Desc
        {
            get
            {
                return _desc;
            }
            set
            {
                if (value != _desc)
                {
                    _desc = value;
                    OnPropertyChanged("Desc");
                }
            }
        }


        public System.Windows.Controls.Image Img
        {
            get
            {
                return _image;
            }
            set
            {
                if (_image != value)
                {
                    _image = value;
                    OnPropertyChanged("Image");
                }
            }
        }

        public ObservableCollection<Resurs> Resource
        {
            get
            {
                return _resursi;
            }
            set
            {
                if (_resursi != value)
                {
                    _resursi = value;
                    OnPropertyChanged("Resource");
                }
            }
        }
            

        public Tip(string id,string s, string d, System.Windows.Controls.Image image) 
        {
                Id = id;
                Name = s;
                Desc = d;
                Img = new System.Windows.Controls.Image();
                Img.Source = image.Source;
                Resource = new ObservableCollection<Resurs>();
            
            
        }
        public ImageSource CreateResizedImage(ImageSource source, int width, int height)
        {
            // Target Rect for the resize operation
            Rect rect = new Rect(0, 0, width, height);

            // Create a DrawingVisual/Context to render with
            DrawingVisual drawingVisual = new DrawingVisual();
            using (DrawingContext drawingContext = drawingVisual.RenderOpen())
            {
                drawingContext.DrawImage(source, rect);
            }

            // Use RenderTargetBitmap to resize the original image
            RenderTargetBitmap resizedImage = new RenderTargetBitmap(
                (int)rect.Width, (int)rect.Height,  // Resized dimensions
                96, 96,                             // Default DPI values
                PixelFormats.Default);              // Default pixel format
            resizedImage.Render(drawingVisual);

            // Return the resized image
            return resizedImage;
        }
        /*public static System.Windows.Controls.Image resizeImage(System.Windows.Controls.Image imgToResize, Size size)
        {
            return (System.Windows.Controls.Image)(new Bitmap());
        }
        private static RoutedCommand loadImage = new RoutedCommand();*/
        /* private void LoadHandler(object sender, ExecutedRoutedEventArgs e)
         {
             OpenFileDialog openFileDialog = new OpenFileDialog();
             openFileDialog.Filter = "Images|*.jpg;*.png";
             if (openFileDialog.ShowDialog() == true)
             {
                 string url = openFileDialog.FileName;
                 Img = new BitmapImage(new Uri(url, UriKind.Absolute));
             }
         }*/
    }
}
