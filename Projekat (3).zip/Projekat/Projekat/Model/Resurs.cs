﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Projekat.Model
{
    
    public class Resurs:  INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        private string _name;
        private string _id;
        private string _desc;
        private Tip _type;
        private bool _renewable;
        private bool _strategicValue;
        private bool _exploitable;
        private string _munit;
        private double _price;
        private DateTime _discoveryDate;
        private string _freq;
        private System.Windows.Controls.Image _image;
        private List<Etiketa> _tags;


        public Resurs(List<Etiketa> et,string id, string name, string opis,
            string unit,string freq,Tip type, bool renew, bool svalue, bool exploit, double price, DateTime Date, System.Windows.Controls.Image image)
        {
            Name = name;
            Id = id;
            Munit = unit;
            Type = type;
            Desc = opis;
            Renewable = renew;
            StrategicValue = svalue;
            Exploitable = exploit;
            Price = price;
            _discoveryDate = Date;
            Freq = freq;
            Tags = new List<Etiketa>();
            foreach (Etiketa e in et)
            {
                Tags.Add(e);
            }
            if (image.Source != null)
            {
                Img = new System.Windows.Controls.Image();
                Img.Source = image.Source;
            }
            else
            {
                Img = type.Img;
            }
        
        }
        public Resurs()
        { }


        public System.Windows.Controls.Image Img
        {
            get
            {
                return _image;
            }
            set
            {
                if (_image != value)
                {
                    _image = value;
                    OnPropertyChanged("Image");
                }
            }
        }
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (value != _name)
                {
                    _name = value;
                    OnPropertyChanged("Name");
                }
            }
        }
        public string Freq
        {
            get
            {
                return _freq;
            }
            set
            {
                if (value != _freq)
                {
                    _freq = value;
                    OnPropertyChanged("Freq");
                }
            }
        }
        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                if (value != _id)
                {
                    _id = value;
                    OnPropertyChanged("Id");
                }
            }
        }
        public string Desc
        {
            get
            {
                return _desc;
            }
            set
            {
                if (value != _desc)
                {
                    _desc = value;
                    OnPropertyChanged("Desc");
                }
            }
        }
        public Tip Type
        {
            get
            {
                return _type;
            }
            set
            {
                if (value != _type)
                {
                    _type = value;
                    OnPropertyChanged("Type");
                }
            }
        }
        public bool Renewable
        {
            get
            {
                return _renewable;
            }
            set
            {
                if (value != _renewable)
                {
                    _renewable = value;
                    OnPropertyChanged("Renewable");
                }
            }
        }
        public bool StrategicValue
        {
            get
            {
                return _strategicValue;
            }
            set
            {
                if (value != _strategicValue)
                {
                    _strategicValue = value;
                    OnPropertyChanged("StrategicValue");
                }
            }
        }
        public bool Exploitable
        {
            get
            {
                return _exploitable;
            }
            set
            {
                if (value != _exploitable)
                {
                    _exploitable = value;
                    OnPropertyChanged("Exploitable");
                }
            }
        }
        public string Munit
        {
            get
            {
                return _munit;
            }
            set
            {
                if (value != _munit)
                {
                    _munit = value;
                    OnPropertyChanged("Munit");
                }
            }
        }
        public double Price
        {
            get
            {
                return _price;
            }
            set
            {
                if (value != _price)
                {
                    _price = value;
                    OnPropertyChanged("Price");
                }
            }
        }
        public DateTime DiscoveryDate
        {
            get
            {
                return _discoveryDate;
            }
            set
            {
                if (value != _discoveryDate)
                {
                    _discoveryDate = value;
                    OnPropertyChanged("DiscoveryDate");
                }
            }
        }

        public List<Etiketa> Tags {
            get
            {
                return _tags;
            }
            set
            {
                if (value != _tags)
                {
                    _tags = value;
                    OnPropertyChanged("Tags");
                }
               
            }
        }
           

        public static ImageSource CreateResizedImage(ImageSource source, int width, int height)
        {
            // Target Rect for the resize operation
            Rect rect = new Rect(0, 0, width, height);

            // Create a DrawingVisual/Context to render with
            DrawingVisual drawingVisual = new DrawingVisual();
            using (DrawingContext drawingContext = drawingVisual.RenderOpen())
            {
                drawingContext.DrawImage(source, rect);
            }

            // Use RenderTargetBitmap to resize the original image
            RenderTargetBitmap resizedImage = new RenderTargetBitmap(
                (int)rect.Width, (int)rect.Height,  // Resized dimensions
                96, 96,                             // Default DPI values
                PixelFormats.Default);              // Default pixel format
            resizedImage.Render(drawingVisual);

            // Return the resized image
            return resizedImage;
        }


    }
}
