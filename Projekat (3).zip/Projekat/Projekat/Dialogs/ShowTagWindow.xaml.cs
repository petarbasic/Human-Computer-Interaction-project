﻿using Projekat.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat.Dialogs
{
    /// <summary>
    /// Interaction logic for ShowTagWindow.xaml
    /// </summary>
    public partial class ShowTagWindow : Window
    {
        public ShowTagWindow()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var s = new ChangeTagWindow(dgrMain.SelectedIndex);
            s.ShowDialog();
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            var s = new AddTagWindow();
            s.ShowDialog();
        }
        void DataGrid_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            e.Row.Header = (e.Row.GetIndex() + 1).ToString();
            dgrMain.SelectedItem = null;

        }
        protected override void OnClosed(EventArgs e)
        {
            dgrMain.SelectedItem = null;
            base.OnClosed(e);
        }
        private void DeleteT_Click(object sender, RoutedEventArgs e)
        {
            foreach (Resurs r in MainWindow.Resursi)
            {
                if (r.Type.Id.Equals(((Etiketa)dgrMain.SelectedItem).Id))
                {
                    System.Windows.MessageBox.Show("Oznacena etiketa se koristi u resursima!\n Da biste obrisali selektovanu etiketu prvo\n izmenite ili izbrisite resurse sa datom etiketom.");
                    return;
                }
            }

            if (MessageBox.Show("Da li ste sigurni da zelite da izbrisete ovu etiketu?\n\n   Id:         " + ((Etiketa)dgrMain.SelectedItem).Id + " \n" + "   Opis:     " + ((Etiketa)dgrMain.SelectedItem).Desc, "Izbrisi etiketu", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
            {

            }
            else
            {
                MainWindow.Etikete.Remove((Etiketa)dgrMain.SelectedItem);
                dgrMain.Items.Refresh();

            }
        }
    }
}
