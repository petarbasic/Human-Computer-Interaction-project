﻿using Projekat.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using RadioButton = System.Windows.Controls.RadioButton;

namespace Projekat.Dialogs
{
    /// <summary>
    /// Interaction logic for ChangeResource.xaml
    /// </summary>
    public partial class ChangeResource : Window
    {
        private RadioButton radbut;
        private RadioButton radbut1;
        private RadioButton radbut2;
        public ChangeResource(int index)
        {
            InitializeComponent();
            
            radbut = new RadioButton();
            radbut1 = new RadioButton();
            radbut2 = new RadioButton();
            if (index != -1)
            {
                listBox.SelectedIndex = index;
            }
            comboBoxunit.ItemsSource = MainWindow.units;
            comboBoxfreq.ItemsSource = MainWindow.freq;
        }
        
        private void radioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            if (ck.IsChecked.Value)
                radbut = ck;
        }
        private void radioButton_Checked1(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            if (ck.IsChecked.Value)
                radbut1 = ck;
        }
        private void radioButton_Checked2(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            if (ck.IsChecked.Value)
                radbut2 = ck;
        }
        private void Ikonica_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Izaberite sliku";
            op.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
              "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
              "Portable Network Graphic (*.png)|*.png";
            if (op.ShowDialog() == (DialogResult)1)
            {
                imgIcon.Source = new BitmapImage(new Uri(op.FileName));
            }
        }
        private void Change()
        {
            List<Etiketa> li = new List<Etiketa>();
            foreach (Etiketa et in listBoxTag.SelectedItems)
            {
                li.Add(et);
            }
            if (!validate())
            {
                return;
            }
            MainWindow.Resursi[listBox.SelectedIndex].Id = textBoxID.Text;
            MainWindow.Resursi[listBox.SelectedIndex].Name = textBoxName.Text;
            MainWindow.Resursi[listBox.SelectedIndex].Price = Double.Parse(textBoxPrice.Text);
            MainWindow.Resursi[listBox.SelectedIndex].Desc = textBoxDesc.Text;
            MainWindow.Resursi[listBox.SelectedIndex].DiscoveryDate = DatePick.SelectedDate.Value;
            MainWindow.Resursi[listBox.SelectedIndex].Freq = (string)comboBoxfreq.SelectedItem;
            MainWindow.Resursi[listBox.SelectedIndex].Munit = (string)comboBoxunit.SelectedItem;
            MainWindow.Resursi[listBox.SelectedIndex].Type = (Tip)comboBox.SelectedItem;
            MainWindow.Resursi[listBox.SelectedIndex].Img.Source = imgIcon.Source;
            MainWindow.Resursi[listBox.SelectedIndex].Renewable = radbut.IsChecked.Value;
            MainWindow.Resursi[listBox.SelectedIndex].Exploitable = radbut2.IsChecked.Value;
            MainWindow.Resursi[listBox.SelectedIndex].StrategicValue = radbut1.IsChecked.Value;
            MainWindow.Resursi[listBox.SelectedIndex].Tags = li;
            System.Windows.MessageBox.Show("Izmena uspesno izvrsena");
        }
        private bool validate()
        {
            Regex rgx = new Regex(@"\d");
            double d = new double();
            bool price = double.TryParse(textBoxPrice.Text, out d);
            bool v = true;
            if (!rgx.IsMatch(textBoxID.Text))
            {
                textBoxID.BorderBrush = Brushes.Red;
                v = false;
            }
            if (textBoxName.Text.Equals("") || !price)
            {

                v = false;
            }
            if (!v)
            {
                System.Windows.MessageBox.Show("Greska pri unosu, ili nisu uneta sva polja validno");
            }
            return v;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!(listBox.SelectedItem == null))
            {
                
                foreach (Tip t in MainWindow.Tipovi)
                {
                    if (t.Id.Equals(((Resurs)listBox.SelectedItem).Type.Id))
                    {
                        if (((Resurs)listBox.SelectedItem).Type.Id.Equals(((Tip)comboBox.SelectedItem).Id))
                        {
                            foreach(Resurs s in t.Resource)
                            {
                                if (s.Id.Equals(((Resurs)listBox.SelectedItem).Id))
                                {
                                    Change();
                                    t.Resource[t.Resource.IndexOf(s)] = MainWindow.Resursi[listBox.SelectedIndex];
                                    break;
                                }
                            }
                        }
                        else
                        {
                            t.Resource.Remove(MainWindow.Resursi[listBox.SelectedIndex]);
                            Change();
                            MainWindow.Tipovi[comboBox.SelectedIndex].Resource.Add(MainWindow.Resursi[listBox.SelectedIndex]);
                        }
                        break;
                    }
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Morate selektovati neki resurs sa liste desno!");
            }

        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            listBoxTag.SelectedItems.Clear();
            Resurs r = (Resurs)listBox.SelectedItem;
            if (r != null)
            {
                foreach (Etiketa t in r.Tags)
                {
                    listBoxTag.SelectedItems.Add(t);
                }
            }
          
        }
        protected override void OnClosed(EventArgs e)
        {
            listBox.SelectedItem = null;
            base.OnClosed(e);
        }
    }
   
    [ValueConversion(typeof(bool), typeof(bool))]
    public class InverseBooleanConverter : IValueConverter
    {
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            if (targetType != typeof(bool))
                throw new InvalidOperationException("The target must be a boolean");

            return !(bool)value;
        }

        public object ConvertBack(object value, Type targetType, object parameter,
            System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }

        #endregion
    }


}
