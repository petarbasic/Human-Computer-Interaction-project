﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat.Dialogs
{
    /// <summary>
    /// Interaction logic for AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        public AddWindow()
        {
            InitializeComponent();
            this.DataContext = MainWindow.Tipovi;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            
                OpenFileDialog op = new OpenFileDialog();
                op.Title = "Izaberite sliku";
                op.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
                  "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
                  "Portable Network Graphic (*.png)|*.png";
            if (op.ShowDialog() == (DialogResult)1)
            {
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
            }
        }
        
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox tb = (System.Windows.Controls.TextBox)sender;
            tb.Text = string.Empty;
            tb.GotFocus -= TextBox_GotFocus;
        }

        private void TextBox1_LostFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox box = sender as System.Windows.Controls.TextBox;
            if (box.Text.Trim().Equals(string.Empty))
            {
                box.Text = "Ovde unesite opis tipa";
                box.Foreground = Brushes.LightGray;
                box.GotFocus += TextBox_GotFocus;
            }
        }
        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox box = sender as System.Windows.Controls.TextBox;
            if (box.Text.Trim().Equals(string.Empty))
            {
                box.Text = "Ovde unesite naziv tipa";
                box.Foreground = Brushes.LightGray;
                box.GotFocus += TextBox_GotFocus;
            }
        }
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!textBox.Text.Equals("Ovde unesite naziv tipa") && !textBox1.Text.Equals("Ovde unesite opis tipa"))
            {
                if (!textBox.Text.Equals("") && !textBox1.Text.Equals("") && imgPhoto.Source!=null)
                {
                    MainWindow.Tipovi.Add(new Model.Tip(textBox2.Text, textBox.Text, textBox1.Text,imgPhoto));
                    System.Windows.MessageBox.Show("Uspesno ste dodali novi tip!");
                    textBox.Text = "";
                    textBox1.Text = "";
                    this.Close();
                }
                else
                {
                    System.Windows.MessageBox.Show("Morate uneti sve parametre i izabrati ikonicu!");
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Unesite podatke za novi tip!");
            }
        }
    }
}
