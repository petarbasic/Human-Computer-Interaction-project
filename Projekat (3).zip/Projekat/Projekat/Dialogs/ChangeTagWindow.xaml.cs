﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat.Dialogs
{
    /// <summary>
    /// Interaction logic for ChangeTagWindow.xaml
    /// </summary>
    public partial class ChangeTagWindow : Window
    {
        public ChangeTagWindow(int index)
        {
            InitializeComponent();
            this.DataContext = MainWindow.Etikete;
            if (index != -1)
            {
                listBox.SelectedIndex = index;
            }
            
        }
        private void ChangeTagClick(object sender, RoutedEventArgs e)
        {
            Regex rgx = new Regex(@"\d");
            if (colorpick.SelectedColor != null && rgx.IsMatch(textBox1.Text))
            {
                MainWindow.Etikete[listBox.SelectedIndex].Id = textBox1.Text;
                MainWindow.Etikete[listBox.SelectedIndex].Boja = colorpick.SelectedColor.Value;
                MainWindow.Etikete[listBox.SelectedIndex].Desc = textBox.Text;
                listBox.SelectedItem = null;
                System.Windows.MessageBox.Show("Izmena etikete uspesna!");
            }
            else
            {
                System.Windows.MessageBox.Show("Morate uneti boju i Id!");
            }
           
        }

       

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Binding myBinding = new Binding();
            myBinding.ElementName = "listBox";
            myBinding.Path = new PropertyPath("SelectedItem.Boja");
            myBinding.Mode = BindingMode.OneWay;
            myBinding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
            colorpick.SetBinding(Xceed.Wpf.Toolkit.ColorPicker.SelectedColorProperty, myBinding);
        }

       
    }
}
