﻿using Projekat.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using RadioButton = System.Windows.Controls.RadioButton;


namespace Projekat.Dialogs
{
    /// <summary>
    /// Interaction logic for ResourceAddWindow.xaml
    /// </summary>
    public partial class ResourceAddWindow : Window
    {
        private RadioButton radbut;
        private RadioButton radbut1;
        private RadioButton radbut2;
        private Resurs re;


        public ResourceAddWindow()
        {
            InitializeComponent();
            this.DataContext = MainWindow.Resursi;
            radbut = new RadioButton();
            radbut1 = new RadioButton();
            radbut2 = new RadioButton();
            
            
            comboBoxunit.ItemsSource = MainWindow.units;
            comboBoxfreq.ItemsSource = MainWindow.freq;
          



        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double d = new double();
            double.TryParse(textBoxPrice.Text, out d);
            List<Etiketa> li = new List<Etiketa>();
            foreach(Etiketa et in listBoxTag.SelectedItems)
            {
                li.Add(et);
            }
            if (!validate())
            {
                return;
            }
            foreach(Tip t in MainWindow.Tipovi)
            {
                if (t.Id.Equals(((Tip)comboBox.SelectedItem).Id))
                {
                    re = new Model.Resurs(li, textBoxID.Text, textBoxName.Text, textBoxDesc.Text, (string)comboBoxunit.SelectedItem, (string)comboBoxfreq.SelectedItem, (Tip)comboBox.SelectedItem, radbut.IsChecked.Value, radbut1.IsChecked.Value, radbut2.IsChecked.Value, d, DatePick.SelectedDate.Value, imgIcon);
                    MainWindow.Resursi.Add(re);
                    t.Resource.Add(re);

                    //System.Windows.MessageBox.Show("Uspesno ste dodali resurs!");
                    foreach (System.Windows.Controls.Control txtBox in bigGrid.Children)
                    {
                        if (txtBox.GetType() == typeof(System.Windows.Controls.TextBox))
                            ((System.Windows.Controls.TextBox)txtBox).Text = string.Empty;
                        if (txtBox.GetType() == typeof(System.Windows.Controls.ComboBox))
                            ((System.Windows.Controls.ComboBox)txtBox).SelectedItem=null;
                        if (txtBox.GetType() == typeof(System.Windows.Controls.RadioButton))
                            ((System.Windows.Controls.RadioButton)txtBox).IsChecked = false;
                        if (txtBox.GetType() == typeof(System.Windows.Controls.DatePicker))
                            ((System.Windows.Controls.DatePicker)txtBox).SelectedDate=null;
                        listBoxTag.SelectedItems.Clear();
                        imgIcon.Source = null;
                    }
                    break;
                }
            }
            
            
        }
        private bool validate()
        {
            Regex rgx = new Regex(@"\d");
            double d = new double();
            bool price =double.TryParse(textBoxPrice.Text, out d);
            bool v=true;
            if (!rgx.IsMatch(textBoxID.Text)) {
                textBoxID.BorderBrush = Brushes.Red;
                v = false;
            }
            if(textBoxName.Text.Equals("") || !price || comboBox.SelectedIndex==-1 || comboBoxfreq.SelectedIndex == -1 || comboBoxunit.SelectedIndex == -1 || !(listBoxTag.SelectedItems.Count>0)) {
                
                v = false;
            }
            if (!v)
            {
                System.Windows.MessageBox.Show("Greska pri unosu, ili nisu uneta sva polja validno");
            }
            return v;
        }
        private void radioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            if (ck.IsChecked.Value)
                radbut = ck;
        }
        private void radioButton_Checked1(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            if (ck.IsChecked.Value)
                radbut1 = ck;
        }
        private void radioButton_Checked2(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            if (ck.IsChecked.Value)
                radbut2 = ck;
        }

        private void Ikonica_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Izaberite sliku";
            op.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
              "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
              "Portable Network Graphic (*.png)|*.png";
            if (op.ShowDialog() == (DialogResult)1)
            {
                imgIcon.Source = new BitmapImage(new Uri(op.FileName));
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            
        }
        private int brojac = 0;
        private bool uToku = false;
       public void demo_mode()
        {
            // await Task.Delay(5000);
            //SetCursor(157, 70);
                uToku = true;
            
                DispatcherTimer dispatcherTimer = new DispatcherTimer();
                dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 100);
                dispatcherTimer.Tick += new EventHandler(DispatcherTimer_Tick);
                dispatcherTimer.Start();
                brojac = 1;
                this.KeyDown += new System.Windows.Input.KeyEventHandler(OnKeyDown);
            
                
            
        }
        private void OnKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Escape && uToku)
            {
                uToku = false;
                this.Close();
            }
            

        }
        String imeDemo = "Naziv resursa";
        String IdDemo = "123";
        String opisDemo = "Opis resursa";
        String priceDemo = " 5600";
        [DllImport("User32.dll")]
        private static extern bool SetCursorPos(int X, int Y);
       
        private void DispatcherTimer_Tick(object sender, EventArgs e)
        {
            if (uToku)
            {
                brojac++;
               if (brojac < IdDemo.Length + 2)
                {
                   Point buttonCentre = new Point(textBoxID.Width / 2, textBoxID.Height / 2);
                    Point p = textBoxID.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X,(int)p.Y);
                    textBoxID.Text += IdDemo[brojac - 2];
                    //brojac++;
                }
                if (brojac >= 11 && brojac < imeDemo.Length + 11)
                {
                   Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                   SetCursorPos((int)p.X, (int)p.Y);
                    textBoxName.Text += imeDemo[brojac - 11];
                    // brojac++;
                }
                if (brojac == 26)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y+37);
                }
                if (brojac == 31)
                {
                    comboBox.IsDropDownOpen = true;
                    
                }
                if (brojac == 39)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y + 55);
                    
                }
                if (brojac == 45)
                {
                    
                    comboBox.SelectedIndex = 0;
                    
                }
                if (brojac == 50)
                {

                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y + 37);
                    comboBox.IsDropDownOpen = false;
                }
                if (brojac == 55)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X-120, (int)p.Y+70);
                }
                if (brojac == 59)
                {
                    radioButton.IsChecked = true;
                }
                if (brojac == 65)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X-23, (int)p.Y+110);
                }
                if (brojac == 69)
                {
                    radioButton3.IsChecked = true;
                }
                if (brojac == 75)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X - 23, (int)p.Y + 150);
                }
                if (brojac == 79)
                {
                    radioButton5.IsChecked = true;
                }
                if (brojac == 85)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y + 190);
                }
                if (brojac == 89)
                {
                    comboBoxfreq.IsDropDownOpen = true;
                }
                if (brojac == 95)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y + 210);
                }
                if (brojac == 99)
                {
                    comboBoxfreq.SelectedIndex = 0;
                }
                if (brojac == 105)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y + 190);
                    comboBoxfreq.IsDropDownOpen = false;

                }
                if (brojac == 109)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y + 230);
                }
                if (brojac == 115)
                {
                    comboBoxunit.IsDropDownOpen = true;
                }
                if (brojac == 119)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y + 250);
                }
                if (brojac == 125)
                { 
                    comboBoxunit.SelectedIndex = 0;
                }
                if (brojac == 129)
                {
                    Point buttonCentre = new Point(textBoxName.Width / 2, textBoxName.Height / 2);
                    Point p = textBoxName.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y + 230);
                    comboBoxunit.IsDropDownOpen = false;
                }
                if (brojac == 135)
                {
                    Point buttonCentre = new Point(textBoxPrice.Width / 2, textBoxPrice.Height / 2);
                    Point p = textBoxPrice.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y);

                }
                if (brojac>139 && brojac < priceDemo.Length + 139)
                {
                    textBoxPrice.Text += priceDemo[brojac - 139];
                }
                if (brojac ==149)
                { 
                    Point buttonCentre = new Point(textBoxDesc.Width / 2, textBoxDesc.Height / 2);
                    Point p = textBoxDesc.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X+35, (int)p.Y - 70);
                }
                if (brojac == 154)
                {
                    DatePick.IsDropDownOpen = true;
                }
                if (brojac == 159)
                {
                    DatePick.Text = "1/3/1978";
                }
                if (brojac == 164)
                {
                    DatePick.IsDropDownOpen = false;
                }
                if (brojac == 169)
                {
                    Point buttonCentre = new Point(textBoxDesc.Width / 2, textBoxDesc.Height / 2);
                    Point p = textBoxDesc.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y - 5);
                }
                if (brojac >= 174 && brojac < opisDemo.Length + 174)
                {
                    textBoxDesc.Text += opisDemo[brojac - 174];
                }
                
                if (brojac == 185)
                {
                    Point buttonCentre = new Point(listBoxTag.Width/2, listBoxTag.Height/2);
                    Point p = listBoxTag.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y-15);
                }
                if (brojac == 190)
                {
                    listBoxTag.SelectedIndex = 2;
                }
                if (brojac == 196)
                {
                    Point buttonCentre = new Point(button.Width / 2, button.Height /2);
                    Point p = button.PointToScreen(buttonCentre);
                    SetCursorPos((int)p.X, (int)p.Y);
                }
                if (brojac == 202)
                {
                   button.RaiseEvent(new RoutedEventArgs(System.Windows.Controls.Primitives.ButtonBase.ClickEvent));
                }
                if (brojac == 206)
                {
                    foreach (Tip t in MainWindow.Tipovi)
                    {
                        if (t.Resource.Contains(re))
                        {
                            t.Resource.Remove(re);
                            break;
                        }
                    }
                    MainWindow.Resursi.Remove(re);
                    
                }
                if (brojac == 220)
                {
                    demo_mode();
                }

            }
        }
    }
}
