﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat.Dialogs
{
    /// <summary>
    /// Interaction logic for AddTagWindow.xaml
    /// </summary>
    public partial class AddTagWindow : Window
    {
        public AddTagWindow()
        {
            InitializeComponent();
            this.DataContext = MainWindow.Etikete;

        }
        private void AddTagClick(object sender, RoutedEventArgs e)
        {
            Regex rgx = new Regex(@"\d");
            if (colorpick.SelectedColor != null && rgx.IsMatch(textBox1.Text))
            {
                MainWindow.Etikete.Add(new Model.Etiketa(textBox1.Text, textBox.Text, colorpick.SelectedColor.Value));
            }
            else
            {
                System.Windows.MessageBox.Show("Morate uneti boju i Id!");
            }
        }
    }
}
