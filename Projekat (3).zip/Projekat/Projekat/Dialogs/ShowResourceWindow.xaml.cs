﻿using Projekat.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat.Dialogs
{
    /// <summary>
    /// Interaction logic for ShowResourceWindow.xaml
    /// </summary>
    public partial class ShowResourceWindow : Window, INotifyPropertyChanged
    {
        #region PropertyChangedNotifier
        protected virtual void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        #endregion
        private ICollectionView _Itemlist ;
        public ICollectionView Itemlist
        {
            get
            {
                return _Itemlist;
            }
            set
            {
                _Itemlist = value;
                OnPropertyChanged("Itemlist");
            }
        }
        private RadioButton radbut;
        private RadioButton radbut1;
        private RadioButton radbut2;
        public ShowResourceWindow()
        {
            InitializeComponent();
            Itemlist = CollectionViewSource.GetDefaultView(MainWindow.Resursi);

            var yourCostumFilter = new Predicate<object>(item => {
                item = item as Resurs;
                bool retval = true,name=false,id=false,tip=false;
                if ((bool)checkBox_name.IsChecked)
                {
                    if (((Resurs)item).Name.Contains(textBox.Text))
                        name = true;
                    else
                        name = false;
                }
               
                if ((bool)checkBox_id.IsChecked)
                {
                    if (((Resurs)item).Id.Contains(textBox.Text))
                        id = true;
                    else
                        id = false;
                }
                if ((bool)checkBox_tip.IsChecked)
                {
                    if (((Resurs)item).Type.Name.Contains(textBox.Text))
                        tip = true;
                    else
                        tip = false;
                }
                if (!(bool)checkBox_name.IsChecked && !(bool)checkBox_id.IsChecked && !(bool)checkBox_tip.IsChecked)
                {
                    return true;
                }
                return retval && (name||id||tip);
            });
            Itemlist.Filter = yourCostumFilter;
           
            dgrMain.ItemsSource = Itemlist;
            comboBoxunit.ItemsSource = MainWindow.units;
            comboBoxfreq.ItemsSource = MainWindow.freq;
            radbut = new RadioButton();
            radbut1 = new RadioButton();
            radbut2 = new RadioButton();
        }
       
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var s = new ChangeResource(dgrMain.SelectedIndex);
            s.ShowDialog();
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            var s = new ResourceAddWindow();
            s.ShowDialog();
        }
        void DataGrid_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            e.Row.Header = (e.Row.GetIndex()+1).ToString();
            dgrMain.SelectedItem = null;
        }

        protected override void OnClosed(EventArgs e)
        {
            dgrMain.SelectedItem = null;
            base.OnClosed(e);
        }

        private void DeleteR_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Da li ste sigurni da zelite da izbrisete ovaj Resurs?\n\n   Id:          " + ((Resurs)dgrMain.SelectedItem).Id + " \n" + "   Naziv:     " + ((Resurs)dgrMain.SelectedItem).Name, "Izbrisi resurs", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
            {
            }
            else
            { 
                foreach(Tip t in MainWindow.Tipovi)
                {
                    if (t.Resource.Contains((Resurs)dgrMain.SelectedItem))
                    {
                        t.Resource.Remove((Resurs)dgrMain.SelectedItem);
                        break;
                    }
                }
                MainWindow.Resursi.Remove((Resurs)dgrMain.SelectedItem);
                dgrMain.Items.Refresh();
                System.Windows.MessageBox.Show("Odabrani Resurs uspesno obrisan!");

            }
        }
        private void btnBottomMenuHide_Click(object sender, RoutedEventArgs e)
        {
            ShowHideMenu("sbHideBottomMenu", btnBottomMenuHide, btnBottomMenuShow, pnlBottomMenu);
            textBox.IsEnabled = true;
            checkBox_id.IsEnabled = true;
            checkBox_name.IsEnabled = true;
            checkBox_tip.IsEnabled = true;
            var yourCostumFilter = new Predicate<object>(item => {
                item = item as Resurs;
                bool retval = true, name = false, id = false, tip = false;
                if ((bool)checkBox_name.IsChecked)
                {
                    if (((Resurs)item).Name.Contains(textBox.Text))
                        name = true;
                    else
                        name = false;
                }

                if ((bool)checkBox_id.IsChecked)
                {
                    if (((Resurs)item).Id.Contains(textBox.Text))
                        id = true;
                    else
                        id = false;
                }
                if ((bool)checkBox_tip.IsChecked)
                {
                    if (((Resurs)item).Type.Name.Contains(textBox.Text))
                        tip = true;
                    else
                        tip = false;
                }
                if (!(bool)checkBox_name.IsChecked && !(bool)checkBox_id.IsChecked && !(bool)checkBox_tip.IsChecked)
                {
                    return true;
                }
                return retval && (name || id || tip);
            });
            Itemlist.Filter = yourCostumFilter;

            dgrMain.ItemsSource = Itemlist;
            this.Itemlist.Refresh();
        }

        private void btnBottomMenuShow_Click(object sender, RoutedEventArgs e)
        {
            ShowHideMenu("sbShowBottomMenu", btnBottomMenuHide, btnBottomMenuShow, pnlBottomMenu);
            textBox.IsEnabled = false;
            checkBox_id.IsEnabled = false;
            checkBox_name.IsEnabled = false;
            checkBox_tip.IsEnabled = false;
        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        { 
            this.Itemlist.Refresh();
        }
        private void ShowHideMenu(string s, Button btnHide, Button btnShow, StackPanel pnl)
        {
            Storyboard sb = Resources[s] as Storyboard;
            sb.Begin(pnl);

            if (s.Contains("Show"))
            {
                btnHide.Visibility = System.Windows.Visibility.Visible;
                btnShow.Visibility = System.Windows.Visibility.Hidden;
            }
            else if (s.Contains("Hide"))
            {
                btnHide.Visibility = System.Windows.Visibility.Hidden;
                btnShow.Visibility = System.Windows.Visibility.Visible;
            }
        }
        private void radioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            if (ck.IsChecked.Value)
                radbut = ck;
        }
        private void radioButton_Checked1(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            if (ck.IsChecked.Value)
                radbut1 = ck;
        }
        private void radioButton_Checked2(object sender, RoutedEventArgs e)
        {
            RadioButton ck = sender as RadioButton;
            if (ck.IsChecked.Value)
                radbut2 = ck;
        }

        private void ButtonSearch_Click(object sender, RoutedEventArgs e)
        {

            var yourCostumFilter = new Predicate<object>(item => {
                item = item as Resurs;
                bool retval = false;
                if (!textboxId.Text.Equals(""))
                {
                    if (((Resurs)item).Id.Equals(textboxId.Text))
                        retval = true;
                    else
                        return false;
                }
                if (!textboxName.Text.Equals(""))
                {
                    if (((Resurs)item).Name.Equals(textboxName.Text))
                        retval = true;
                    else
                        return false;
                }
                if (!textboxPrice.Text.Equals(""))
                {
                    double d = 1;
                   double.TryParse(textboxId.Text,out d);
                    if (((Resurs)item).Price.Equals(d))
                        retval = true;
                    else
                        return false;
                }
                if (comboBox.SelectedItem!=null)
                {
                    if (((Resurs)item).Type.Id.Equals(((Tip)comboBox.SelectedItem).Id))
                        retval = true;
                    else
                        return false;
                }
                if (DatePick.SelectedDate!=null)
                {
                    if (((Resurs)item).DiscoveryDate.Equals(DatePick.SelectedDate.Value))
                        retval = true;
                    else
                        return false;
                }
                
                if (((Resurs)item).Renewable.Equals(radbut.IsChecked.Value))
                    retval = true;
                else
                    return false;
                if (((Resurs)item).StrategicValue.Equals(radbut1.IsChecked.Value))
                    retval = true;
                else
                    return false;
                if (((Resurs)item).Exploitable.Equals(radbut2.IsChecked.Value))
                    retval = true;
                else
                    return false;
                if (comboBoxfreq.SelectedItem != null)
                {
                    if (((Resurs)item).Freq.Equals((String)comboBoxfreq.SelectedItem))
                        retval = true;
                    else
                        return false;
                }
                if (comboBoxunit.SelectedItem != null)
                {
                    if (((Resurs)item).Munit.Equals((String)comboBoxunit.SelectedItem))
                        retval = true;
                    else
                        return false;
                }
                return retval;
            });
            Itemlist.Filter = yourCostumFilter;

            dgrMain.ItemsSource = Itemlist;
            this.Itemlist.Refresh();
        }
    }
}
