﻿using Projekat.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat.Dialogs
{
    /// <summary>
    /// Interaction logic for ChangeType.xaml
    /// </summary>
    public partial class ChangeType : Window
    {
        public ChangeType(int index)
        {
            InitializeComponent();
            this.DataContext = MainWindow.Tipovi;
            if(index!=-1)
            {
                listBox.SelectedIndex = index;
            }
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (listBox.SelectedItem == null)
            {
                System.Windows.MessageBox.Show("Morate selektovati tip za izmenu u listi sa desne strane prozora!");
                return;
            }
            if (!textBox.Text.Equals("") && !textBox1.Text.Equals("") && imgPhoto.Source != null && !textBox2.Text.Equals("") )
            {
                foreach (Tip t in MainWindow.Tipovi)
                {
                    if (t.Id.Equals(((Tip)listBox.SelectedItem).Id))
                    {
                        t.Id = textBox2.Text;
                        t.Name = textBox.Text;
                        t.Desc = textBox1.Text;
                        t.Img.Source = imgPhoto.Source;
                        break;
                    }
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Izmena neuspesna. Morate uneti sva polja.");
            }
        }
        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            if (listBox.SelectedItem == null)
            {
                System.Windows.MessageBox.Show("Morate selektovati tip za izmenu u listi sa desne strane prozora!");
                return;
            }
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Izaberite sliku";
            op.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
              "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
              "Portable Network Graphic (*.png)|*.png";
            if (op.ShowDialog() == (DialogResult)1)
            {
                imgPhoto.Source = new BitmapImage(new Uri(op.FileName));
            }
        }
    }
}
