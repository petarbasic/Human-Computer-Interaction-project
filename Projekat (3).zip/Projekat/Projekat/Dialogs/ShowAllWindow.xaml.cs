﻿using Projekat.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Projekat.Dialogs
{
    /// <summary>
    /// Interaction logic for ShowAllWindow.xaml
    /// </summary>
    public partial class ShowAllWindow : Window, INotifyPropertyChanged
    {
       
        public ShowAllWindow()
        {
            InitializeComponent();
            this.DataContext = MainWindow.Tipovi;
            


        }

        #region PropertyChangedNotifier
        protected virtual void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddWindow s = new AddWindow();
            s.Activate();
            s.Show();
            
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            var s = new ChangeType(dgrMain.SelectedIndex);
            s.ShowDialog();
            
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            foreach(Resurs r in MainWindow.Resursi)
            {
                if (r.Type.Id.Equals(((Tip)dgrMain.SelectedItem).Id))
                {
                    System.Windows.MessageBox.Show("Oznacenom tipu pripadaju neki resursi! \n Da biste obrisali selektovani tip prvo\n izmenite ili izbrisite resurse sa datim tipom.");
                    return;
                }
            }
            
            if (MessageBox.Show("Da li ste sigurni da zelite da izbrisete ovaj tip?\n\n   Id:          "+ ((Tip)dgrMain.SelectedItem).Id+" \n"+"   Naziv:     "+ ((Tip)dgrMain.SelectedItem).Name, "Izbrisi tip", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
            {
               
            }
            else
            {
                MainWindow.Tipovi.Remove((Tip)dgrMain.SelectedItem);
                dgrMain.Items.Refresh();
                System.Windows.MessageBox.Show("Odabrani tip uspesno obrisan!");
                
            }
            
        }
        void DataGrid_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            e.Row.Header = (e.Row.GetIndex() + 1).ToString();
            dgrMain.SelectedItem = null;
        }
    }
}
